
from mmdandelionsystems import mediameta

a = mediameta.ImageMetadata('~/Yandex.Disk/Images/Космос/6160763385.jpg')

print(a)

